bruker
osamaali
1234