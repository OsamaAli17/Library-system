
from PyQt5.QtWidgets import *
import MySQLdb
import traceback

from PyQt5.uic import loadUiType
import datetime
from xlrd import *
from xlsxwriter import *



ui,_ = loadUiType('library.ui')

login,_ = loadUiType('login.ui')






class Login(QWidget , login):
    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)
        self.pushButton.clicked.connect(self.Handel_Login)
        style = open('themes/qdark.css' , 'r')
        style = style.read()
        self.setStyleSheet(style)

    def Handel_Login(self):
        try:
            self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
            self.cur = self.db.cursor()


            username = self.username.text()
            password = self.user_password.text()

            sql = '''SELECT * FROM users'''

            self.cur.execute(sql)
            data = self.cur.fetchall()
            for row in data:
                if username == row[1] and password == row[3]:
                    print('user match')
                    self.window2 = MainApp()
                    self.close()
                    self.window2.show()
                    return

            self.label.setText('Make Sure You Entered Your Username And Password Correctly')

        except Exception as e:
            # Handle the exception
            print('An error occurred:', str(e))
            traceback.print_exc()




class MainApp(QMainWindow , ui):
    def __init__(self):
        QMainWindow.__init__(self)
        self.setupUi(self)
        # Perform UI changes when the application window is initialized
        self.Handel_UI_Changes()
        self.Handel_Buttons()
        self.QDark_Theme()

        self.Show_Author()
        self.Show_Category()
        self.Show_Publisher()


        self.Show_Category_Combobox()
        self.Show_Author_Combobox()
        self.Show_Publisher_Combobox()

        self.Show_All_Clients()
        self.Show_All_Books()

        self.Show_All_Operations()


    def Handel_UI_Changes(self):
        # Perform UI changes when the application window is initialized
        self.Hiding_Themes()
        self.tabWidget.tabBar().setVisible(False)


    def Handel_Buttons(self):
        # Connect button clicks to their respective functions
        self.BtnShow_Themes.clicked.connect(self.Show_Themes)
        self.BtnHiding_Themes.clicked.connect(self.Hiding_Themes)

        self.BtnOpen_Day_To_Day_Tab.clicked.connect(self.Open_Day_To_Day_Tab)
        self.BtnOpen_Books_Tab.clicked.connect(self.Open_Books_Tab)
        self.BtnOpen_CLients_Tab.clicked.connect(self.Open_CLients_Tab)
        self.BtnOpen_Users_Tab.clicked.connect(self.Open_Users_Tab)
        self.BtnOpen_Settings_Tab.clicked.connect(self.Open_Settings_Tab)

        self.BtnAdd_New_Book.clicked.connect(self.Add_New_Book)
        self.BtnSearch_Books.clicked.connect(self.Search_Books)
        self.BtnEdit_Books.clicked.connect(self.Edit_Books)
        self.BtnDelete_Books.clicked.connect(self.Delete_Books)

        self.BtnAdd_Category.clicked.connect(self.Add_Category)
        self.BtnAdd_Author.clicked.connect(self.Add_Author)
        self.BtnAdd_Publisher.clicked.connect(self.Add_Publisher)

        self.BtnAdd_New_User.clicked.connect(self.Add_New_User)
        self.BtnLogin.clicked.connect(self.Login)
        self.BtnEdit_User.clicked.connect(self.Edit_User)

        self.BtnDark_Orange_Theme.clicked.connect(self.Dark_Orange_Theme)
        self.BtnDark_Blue_Theme.clicked.connect(self.Dark_Blue_Theme)
        self.BtnDark_Gray_Theme.clicked.connect(self.Dark_Gray_Theme)
        self.BtnQDark_Theme.clicked.connect(self.QDark_Theme)

        self.BtnAdd_New_Client.clicked.connect(self.Add_New_Client)
        self.BtnSearch_Client.clicked.connect(self.Search_Client)
        self.BtnEdit_Client.clicked.connect(self.Edit_Client)
        self.BtnDelete_Client.clicked.connect(self.Delete_Client)

        self.BtnHandel_Day_Operations.clicked.connect(self.Handel_Day_Operations)

        self.BtnExport_Day_Operations.clicked.connect(self.Export_Day_Operations)
        self.BtnExport_Books.clicked.connect(self.Export_Books)
        self.BtnExport_Clients.clicked.connect(self.Export_Clients)

    def Show_Themes(self):
        self.BoxShow_Themes.show()

    # This function shows the "BoxShow_Themes" widget.

    def Hiding_Themes(self):
        self.BoxShow_Themes.hide()

    # This function hides the "BoxShow_Themes" widget.

    # The following functions handle opening different tabs in the application:

    def Open_Day_To_Day_Tab(self):
        self.tabWidget.setCurrentIndex(0)

    # Sets the current index of the tabWidget to 0, opening the "Day To Day" tab.

    def Open_Books_Tab(self):
        self.tabWidget.setCurrentIndex(1)

    # Sets the current index of the tabWidget to 1, opening the "Books" tab.

    def Open_CLients_Tab(self):
        self.tabWidget.setCurrentIndex(2)

    # Sets the current index of the tabWidget to 2, opening the "Clients" tab.

    def Open_Users_Tab(self):
        self.tabWidget.setCurrentIndex(3)

    # Sets the current index of the tabWidget to 3, opening the "Users" tab.

    def Open_Settings_Tab(self):
        self.tabWidget.setCurrentIndex(4)

    # Sets the current index of the tabWidget to 4, opening the "Settings" tab.

    # The following function handles day operations:

    def Handel_Day_Operations(self):
        # Retrieve input values
        book_title = self.lineEdit.text()
        client_name = self.lineEdit_29.text()
        type = self.comboBox.currentText()
        days_number = self.Boxdays_number.currentIndex() + 1
        today_date = datetime.date.today()
        to_date = today_date + datetime.timedelta(days=days_number)

        print(today_date)
        print(to_date)

        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Insert the day operation data into the database
        self.cur.execute('''
            INSERT INTO dayoperations(book_name, client, type, days, date, to_date)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (book_title, client_name, type, days_number, today_date, to_date))

        self.db.commit()
        self.statusBar().showMessage('New Operation Added')

        self.Show_All_Operations()

    # This function handles day operations, such as borrowing or returning books.
    # It retrieves input values, inserts the operation data into the database, and shows all operations.

    def Show_All_Operations(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all day operations from the database
        self.cur.execute(''' 
            SELECT book_name, client, type, date, to_date FROM dayoperations
        ''')

        data = self.cur.fetchall()

        print(data)

        # Update the tableWidget with the retrieved data
        self.tableWidget.setRowCount(0)
        self.tableWidget.insertRow(0)
        for row, form in enumerate(data):
            for column, item in enumerate(form):
                self.tableWidget.setItem(row, column, QTableWidgetItem(str(item)))
                column += 1

            row_position = self.tableWidget.rowCount()
            self.tableWidget.insertRow(row_position)

    # This function retrieves all day operations from the database and updates the tableWidget with the data.
    # It also prints the retrieved data.

    ########################################
    ######### Books #################

    def Show_All_Books(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all book data from the database
        self.cur.execute('''
            SELECT book_code, book_name, book_description, book_category, book_author, book_publisher, book_price
            FROM book
        ''')
        data = self.cur.fetchall()

        # Update the tableWidget_5 with the retrieved data
        self.tableWidget_5.setRowCount(0)
        self.tableWidget_5.insertRow(0)
        for row, form in enumerate(data):
            for column, item in enumerate(form):
                self.tableWidget_5.setItem(row, column, QTableWidgetItem(str(item)))
                column += 1

            row_position = self.tableWidget_5.rowCount()
            self.tableWidget_5.insertRow(row_position)

        self.db.close()

    # This function retrieves all book data from the database and updates the tableWidget_5 with the data.

    def Add_New_Book(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve input values
        book_title = self.lineEdit_2.text()
        book_description = self.textEdit.toPlainText()
        book_code = self.lineEdit_3.text()
        book_category = self.comboBox_3.currentText()
        book_author = self.comboBox_4.currentText()
        book_publisher = self.comboBox_5.currentText()
        book_price = self.lineEdit_4.text()

        # Insert the new book data into the database
        self.cur.execute('''
            INSERT INTO book(book_name, book_description, book_code, book_category, book_author, book_publisher, book_price)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        ''', (book_title, book_description, book_code, book_category, book_author, book_publisher, book_price))

        self.db.commit()
        self.statusBar().showMessage('New Book Added')

        # Clear input fields
        self.lineEdit_2.setText('')
        self.textEdit.setPlainText('')
        self.lineEdit_3.setText('')
        self.comboBox_3.setCurrentIndex(0)
        self.comboBox_4.setCurrentIndex(0)
        self.comboBox_5.setCurrentIndex(0)
        self.lineEdit_4.setText('')

        self.Show_All_Books()

    # This function adds a new book to the database based on the input values provided by the user.
    # It also updates the status bar, clears the input fields, and shows all books.

    def Search_Books(self):
        try:
            # Connect to the MySQL database
            self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
            self.cur = self.db.cursor()

            # Retrieve input value
            book_title = self.lineEdit_5.text()

            # Search for the book with the given title in the database
            sql = ''' SELECT * FROM book WHERE book_name = %s'''
            self.cur.execute(sql, [(book_title)])

            data = self.cur.fetchone()

            if data is not None:
                # If the book is found, update the corresponding fields with the retrieved data
                self.lineEdit_8.setText(data[1])
                self.textEdit_2.setPlainText(data[2])
                self.lineEdit_7.setText(data[3])
                self.comboBox_7.setCurrentText(data[4])
                self.comboBox_8.setCurrentText(data[5])
                self.comboBox_6.setCurrentText(data[6])
                self.lineEdit_6.setText(str(data[7]))
            else:
                # If the book is not found, display a warning message
                QMessageBox.warning(self, 'Book Not Found', 'Could not find a book with the given title.')

        except Exception as e:
            # Handle any exceptions that occur during the database operation
            print('An error occurred:', str(e))
            traceback.print_exc()
        finally:
            # Close the database connection
            if self.db:
                self.db.close()

    # This function searches for a book in the database based on the provided title.
    # If the book is found, it updates the corresponding fields with the retrieved data.
    # If the book is not found, it displays a warning message.
    # Any exceptions that occur during the database operation are handled, and the database connection is closed.

    def Edit_Books(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve input values
        book_title = self.lineEdit_8.text()
        book_description = self.textEdit_2.toPlainText()
        book_code = self.lineEdit_7.text()
        book_category = self.comboBox_7.currentText()
        book_author = self.comboBox_8.currentText()
        book_publisher = self.comboBox_6.currentText()
        book_price = self.lineEdit_6.text()

        # Retrieve the search book title for updating the specific book
        search_book_title = self.lineEdit_5.text()

        # Update the book record in the database with the new values
        self.cur.execute('''
            UPDATE book SET book_name=%s, book_description=%s, book_code=%s, book_category=%s, book_author=%s, book_publisher=%s, book_price=%s WHERE book_name=%s
        ''', (book_title, book_description, book_code, book_category, book_author, book_publisher, book_price,
              search_book_title))

        self.db.commit()
        self.statusBar().showMessage('Book updated')
        self.Show_All_Books()

    # This function updates the details of a book in the database based on the provided input values.
    # It retrieves the input values, searches for the book to update, and updates the corresponding fields with the new values.
    # The changes are then committed to the database, the status bar is updated, and all books are shown again.

    def Delete_Books(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve the book title for deletion
        book_title = self.lineEdit_5.text()

        # Display a warning message for confirmation
        warning = QMessageBox.warning(self, 'Delete Book', "Are you sure you want to delete this book?",
                                      QMessageBox.Yes | QMessageBox.No)
        if warning == QMessageBox.Yes:
            # Delete the book record from the database
            sql = ''' DELETE FROM book WHERE book_name = %s '''
            self.cur.execute(sql, [(book_title)])
            self.db.commit()
            self.statusBar().showMessage('Book Deleted')

            self.Show_All_Books

    # This function deletes a book from the database based on the provided book title.
    # It displays a warning message for confirmation and deletes the corresponding record if confirmed.
    # The changes are then committed to the database, the status bar is updated, and all books are shown again.

    def Show_All_Clients(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all client data from the database
        self.cur.execute('''
            SELECT client_name, client_email, client_nationalid
            FROM clients
        ''')
        data = self.cur.fetchall()

        print(data)

        # Update the tableWidget_6 with the retrieved data
        self.tableWidget_6.setRowCount(0)
        self.tableWidget_6.insertRow(0)
        for row, form in enumerate(data):
            for column, item in enumerate(form):
                self.tableWidget_6.setItem(row, column, QTableWidgetItem(str(item)))
                column += 1

            row_position = self.tableWidget_6.rowCount()
            self.tableWidget_6.insertRow(row_position)

        self.db.close()

    # This function retrieves all client data from the database and displays it in tableWidget_6.
    # It connects to the MySQL database, executes a SELECT query to retrieve the data, and updates the table widget accordingly.
    # Finally, it closes the database connection.

    def Add_New_Client(self):
        # Retrieve input values
        client_name = self.lineEdit_22.text()
        client_email = self.lineEdit_23.text()
        client_nationalid = self.lineEdit_24.text()

        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Insert the new client record into the database
        self.cur.execute('''
            INSERT INTO clients(client_name, client_email, client_nationalid)
            VALUES (%s, %s, %s)
        ''', (client_name, client_email, client_nationalid))
        self.db.commit()
        self.db.close()
        self.statusBar().showMessage('New Client Added')
        self.Show_All_Clients()

    # This function adds a new client to the database based on the provided input values.
    # It retrieves the input values, connects to the MySQL database, and inserts the new client record.
    # The changes are then committed to the database, the status bar is updated, and all clients are shown again.

    def Search_Client(self):
        # Retrieve the client's national ID for searching
        client_national_id = self.lineEdit_25.text()

        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Execute the SELECT query to retrieve the client record based on the national ID
        sql = '''SELECT * FROM clients WHERE client_nationalid = %s'''
        self.cur.execute(sql, [(client_national_id)])
        data = self.cur.fetchone()

        if data is not None:
            # Display the retrieved client data in the respective line edit fields
            self.lineEdit_28.setText(data[1])
            self.lineEdit_27.setText(data[2])
            self.lineEdit_26.setText(data[3])
        else:
            # No client record found, clear the line edit fields and print a message
            self.lineEdit_28.setText("")
            self.lineEdit_27.setText("")
            self.lineEdit_26.setText("")
            print("Client not found")

        self.db.close()

    # This function searches for a client in the database based on the provided national ID.
    # It connects to the MySQL database, executes a SELECT query to retrieve the client record, and displays the data if found.
    # If no client record is found, it clears the respective line edit fields and prints a message.
    # Finally, it closes the database connection.

    def Edit_Client(self):
        # Retrieve input values
        client_original_national_id = self.lineEdit_25.text()
        client_name = self.lineEdit_28.text()
        client_email = self.lineEdit_27.text()
        client_national_id = self.lineEdit_26.text()

        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Update the client record in the database with the new values
        self.cur.execute('''
            UPDATE clients SET client_name=%s, client_email=%s, client_nationalid=%s WHERE client_nationalid=%s
        ''', (client_name, client_email, client_national_id, client_original_national_id))
        self.db.commit()
        self.db.close()
        self.statusBar().showMessage('Client Data Updated')
        self.Show_All_Clients()

    # This function updates the details of a client in the database based on the provided input values.
    # It retrieves the input values, connects to the MySQL database, and updates the client record.
    # The changes are then committed to the database, the status bar is updated, and all clients are shown again.

    def Delete_Client(self):
        # Retrieve the original national ID of the client to be deleted
        client_original_national_id = self.lineEdit_25.text()

        # Show a warning message box to confirm client deletion
        warning_message = QMessageBox.warning(self, "Delete Client", "Are you sure you want to delete this client?",
                                              QMessageBox.Yes | QMessageBox.No)

        if warning_message == QMessageBox.Yes:
            # Connect to the MySQL database
            self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
            self.cur = self.db.cursor()

            # Execute the DELETE query to remove the client record from the database
            sql = '''DELETE FROM clients WHERE client_nationalid = %s'''
            self.cur.execute(sql, [(client_original_national_id)])

            self.db.commit()
            self.db.close()
            self.statusBar().showMessage('Client Deleted')
            self.Show_All_Clients()

    # This function deletes a client from the database based on the provided national ID.
    # It retrieves the original national ID of the client to be deleted, shows a warning message box for confirmation,
    # connects to the MySQL database, executes the DELETE query, and commits the changes to the database.
    # Finally, it closes the database connection, updates the status bar, and shows all clients again.

    def Add_New_User(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve input values
        username = self.lineEdit_9.text()
        email = self.lineEdit_10.text()
        password = self.lineEdit_11.text()
        password2 = self.lineEdit_12.text()

        if password == password2:
            # Insert the new user record into the database
            self.cur.execute('''
                INSERT INTO users(user_name, user_email, user_password)
                VALUES (%s, %s, %s)
            ''', (username, email, password))

            self.db.commit()
            self.statusBar().showMessage('New User Added')
        else:
            self.label_30.setText('Please add a valid password twice')

    # This function adds a new user to the database based on the provided input values.
    # It connects to the MySQL database, retrieves the input values, and inserts the new user record.
    # If the passwords provided do not match, it displays an error message.
    # Finally, it commits the changes to the database and updates the status bar.

    def Login(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve input values
        username = self.lineEdit_14.text()
        password = self.lineEdit_13.text()

        # Retrieve all user records from the database
        sql = '''SELECT * FROM users'''
        self.cur.execute(sql)
        data = self.cur.fetchall()

        for row in data:
            if username == row[1] and password == row[3]:
                # Username and password match, display a message and enable a group box
                print('User match')
                self.statusBar().showMessage('Valid Username & Password')
                self.groupBox_4.setEnabled(True)

                # Display user data in respective line edit fields
                self.lineEdit_17.setText(row[1])
                self.lineEdit_15.setText(row[2])
                self.lineEdit_16.setText(row[3])

    # This function performs a login operation by comparing the input username and password with the user records in the database.
    # It connects to the MySQL database, retrieves the input values, executes a SELECT query to retrieve all user records,
    # and compares the input values with each row of data fetched from the database.
    # If a match is found, it displays a success message, enables a group box, and populates line edit fields with user data.

    def Edit_User(self):
        # Retrieve input values
        username = self.lineEdit_17.text()
        email = self.lineEdit_15.text()
        password = self.lineEdit_16.text()
        password2 = self.lineEdit_18.text()
        original_name = self.lineEdit_14.text()

        if password == password2:
            # Connect to the MySQL database
            self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
            self.cur = self.db.cursor()

            # Execute the UPDATE query to update the user record in the database
            self.cur.execute('''
                UPDATE users SET user_name=%s, user_email=%s, user_password=%s WHERE user_name=%s
            ''', (username, email, password, original_name))

            self.db.commit()
            self.statusBar().showMessage('User Data Updated Successfully')
        else:
            print('Make sure you entered your password correctly')

    # This function updates the user data in the database based on the provided input values.
    # It retrieves the input values and the original username, connects to the MySQL database,
    # executes the UPDATE query, and commits the changes to the database.
    # If the passwords provided do not match, it displays an error message.

    def Add_Category(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve the category name from the input field
        category_name = self.lineEdit_19.text()

        # Insert the new category into the database
        self.cur.execute('''
            INSERT INTO category (category_name) VALUES (%s)
        ''', (category_name,))

        self.db.commit()
        self.statusBar().showMessage('New Category Added')
        self.lineEdit_19.setText('')
        self.Show_Category()
        self.Show_Category_Combobox()

    # This function adds a new category to the database based on the provided category name.
    # It connects to the MySQL database, retrieves the category name from the input field,
    # and inserts the new category into the database.
    # Finally, it commits the changes to the database, updates the status bar, and shows the updated category list.

    def Show_Category(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all category names from the database
        self.cur.execute('''SELECT category_name FROM category''')
        data = self.cur.fetchall()

        if data:
            # Clear the table widget and insert the retrieved data
            self.tableWidget_2.setRowCount(0)
            self.tableWidget_2.insertRow(0)

            for row, form in enumerate(data):
                for column, item in enumerate(form):
                    self.tableWidget_2.setItem(row, column, QTableWidgetItem(str(item)))
                    column += 1

                row_position = self.tableWidget_2.rowCount()
                self.tableWidget_2.insertRow(row_position)

    # This function retrieves all category names from the database and displays them in the category table widget.
    # It connects to the MySQL database, executes the SELECT query to retrieve category names,
    # and populates the table widget with the fetched data.

    def Add_Author(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve the author name from the input field
        author_name = self.lineEdit_20.text()

        # Insert the new author into the database
        self.cur.execute('''
            INSERT INTO authors (author_name) VALUES (%s)
        ''', (author_name,))

        self.db.commit()
        self.lineEdit_20.setText('')
        self.statusBar().showMessage('New Author Added')
        self.Show_Author()
        self.Show_Author_Combobox()

    # This function adds a new author to the database based on the provided author name.
    # It connects to the MySQL database, retrieves the author name from the input field,
    # and inserts the new author into the database.
    # Finally, it commits the changes to the database, updates the status bar, and shows the updated author list.

    def Show_Author(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all author names from the database
        self.cur.execute('''SELECT author_name FROM authors''')
        data = self.cur.fetchall()

        if data:
            # Clear the table widget and insert the retrieved data
            self.tableWidget_3.setRowCount(0)
            self.tableWidget_3.insertRow(0)

            for row, form in enumerate(data):
                for column, item in enumerate(form):
                    self.tableWidget_3.setItem(row, column, QTableWidgetItem(str(item)))
                    column += 1

                row_position = self.tableWidget_3.rowCount()
                self.tableWidget_3.insertRow(row_position)

    # This function retrieves all author names from the database and displays them in the author table widget.
    # It connects to the MySQL database, executes the SELECT query to retrieve author names,
    # and populates the table widget with the fetched data.

    def Add_Publisher(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve the publisher name from the input field
        publisher_name = self.lineEdit_21.text()

        # Insert the new publisher into the database
        self.cur.execute('''
            INSERT INTO publisher (publisher_name) VALUES (%s)
        ''', (publisher_name,))

        self.db.commit()
        self.lineEdit_21.setText('')
        self.statusBar().showMessage('New Publisher Added')
        self.Show_Publisher()
        self.Show_Publisher_Combobox()

    # This function adds a new publisher to the database based on the provided publisher name.
    # It connects to the MySQL database, retrieves the publisher name from the input field,
    # and inserts the new publisher into the database.
    # Finally, it commits the changes to the database, updates the status bar, and shows the updated publisher list.

    def Show_Publisher(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all publisher names from the database
        self.cur.execute('''SELECT publisher_name FROM publisher''')
        data = self.cur.fetchall()

        if data:
            # Clear the table widget and insert the retrieved data
            self.tableWidget_4.setRowCount(0)
            self.tableWidget_4.insertRow(0)

            for row, form in enumerate(data):
                for column, item in enumerate(form):
                    self.tableWidget_4.setItem(row, column, QTableWidgetItem(str(item)))
                    column += 1

                row_position = self.tableWidget_4.rowCount()
                self.tableWidget_4.insertRow(row_position)

    # This function retrieves all publisher names from the database and displays them in the publisher table widget.
    # It connects to the MySQL database, executes the SELECT query to retrieve publisher names,
    # and populates the table widget with the fetched data.

    def Show_Category_Combobox(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all category names from the database
        self.cur.execute('''SELECT category_name FROM category''')
        data = self.cur.fetchall()

        self.comboBox_3.clear()
        for category in data:
            self.comboBox_3.addItem(category[0])
            self.comboBox_7.addItem(category[0])

    # This function retrieves all category names from the database and displays them in the category combobox.
    # It connects to the MySQL database, executes the SELECT query to retrieve category names,
    # and populates the combobox with the fetched data.

    def Show_Author_Combobox(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all author names from the database
        self.cur.execute('''SELECT author_name FROM authors''')
        data = self.cur.fetchall()

        self.comboBox_4.clear()
        for author in data:
            self.comboBox_4.addItem(author[0])
            self.comboBox_8.addItem(author[0])

    # This function retrieves all author names from the database and displays them in the author combobox.
    # It connects to the MySQL database, executes the SELECT query to retrieve author names,
    # and populates the combobox with the fetched data.

    def Show_Publisher_Combobox(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve all publisher names from the database
        self.cur.execute('''SELECT publisher_name FROM publisher''')
        data = self.cur.fetchall()

        self.comboBox_5.clear()
        for publisher in data:
            self.comboBox_5.addItem(publisher[0])
            self.comboBox_6.addItem(publisher[0])

    # This function retrieves all publisher names from the database and displays them in the publisher combobox.
    # It connects to the MySQL database, executes the SELECT query to retrieve publisher names,
    # and populates the combobox with the fetched data.

    def Export_Day_Operations(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve day operation data from the database
        self.cur.execute('''
            SELECT book_name, client, type, date, to_date FROM dayoperations
        ''')

        data = self.cur.fetchall()

        # Create a new Excel workbook and worksheet
        wb = Workbook('day_operations.xlsx')
        sheet1 = wb.add_worksheet()

        # Write the column headers
        sheet1.write(0, 0, 'book title')
        sheet1.write(0, 1, 'client name')
        sheet1.write(0, 2, 'type')
        sheet1.write(0, 3, 'from - date')
        sheet1.write(0, 4, 'to - date')

        row_number = 1
        for row in data:
            column_number = 0
            for item in row:
                sheet1.write(row_number, column_number, str(item))
                column_number += 1
            row_number += 1

        wb.close()
        self.statusBar().showMessage('Report Created Successfully')

    # This function exports day operation data from the database to an Excel file.
    # It connects to the MySQL database, executes the SELECT query to retrieve day operation data,
    # creates a new Excel workbook and worksheet, writes the data to the worksheet,
    # and saves the workbook as 'day_operations.xlsx'.

    def Export_Books(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve book data from the database
        self.cur.execute('''
            SELECT book_code, book_name, book_description, book_category, book_author, book_publisher, book_price FROM book
        ''')
        data = self.cur.fetchall()

        # Create a new Excel workbook and worksheet
        wb = Workbook('all_books.xlsx')
        sheet1 = wb.add_worksheet()

        # Write the column headers
        sheet1.write(0, 0, 'Book Code')
        sheet1.write(0, 1, 'Book Name')
        sheet1.write(0, 2, 'Book Description')
        sheet1.write(0, 3, 'Book Category')
        sheet1.write(0, 4, 'Book Author')
        sheet1.write(0, 5, 'Book Publisher')
        sheet1.write(0, 6, 'Book Price')

        row_number = 1
        for row in data:
            column_number = 0
            for item in row:
                sheet1.write(row_number, column_number, str(item))
                column_number += 1
            row_number += 1

        wb.close()
        self.statusBar().showMessage('Book Report Created Successfully')

    # This function exports book data from the database to an Excel file.
    # It connects to the MySQL database, executes the SELECT query to retrieve book data,
    # creates a new Excel workbook and worksheet, writes the data to the worksheet,
    # and saves the workbook as 'all_books.xlsx'.

    def Export_Clients(self):
        # Connect to the MySQL database
        self.db = MySQLdb.connect(host='192.168.1.100', user='osama', password='170203', db='library')
        self.cur = self.db.cursor()

        # Retrieve client data from the database
        self.cur.execute('''
            SELECT client_name, client_email, client_nationalid FROM clients
        ''')
        data = self.cur.fetchall()

        # Create a new Excel workbook and worksheet
        wb = Workbook('all_clients.xlsx')
        sheet1 = wb.add_worksheet()

        # Write the column headers
        sheet1.write(0, 0, 'Client Name')
        sheet1.write(0, 1, 'Client Email')
        sheet1.write(0, 2, 'Client NationalID')

        row_number = 1
        for row in data:
            column_number = 0
            for item in row:
                sheet1.write(row_number, column_number, str(item))
                column_number += 1
            row_number += 1

        wb.close()
        self.statusBar().showMessage('Clients Report Created Successfully')

    # This function exports client data from the database to an Excel file.
    # It connects to the MySQL database, executes the SELECT query to retrieve client data,
    # creates a new Excel workbook and worksheet, writes the data to the worksheet,
    # and saves the workbook as 'all_clients.xlsx'.

    def Dark_Blue_Theme(self):
        # Set the dark blue theme for the UI
        style = open('themes/darkblue.css', 'r')
        style = style.read()
        self.setStyleSheet(style)

    # This function sets the dark blue theme for the UI by reading the CSS style from the 'darkblue.css' file.

    def Dark_Gray_Theme(self):
        # Set the dark gray theme for the UI
        style = open('themes/darkgray.css', 'r')
        style = style.read()
        self.setStyleSheet(style)

    # This function sets the dark gray theme for the UI by reading the CSS style from the 'darkgray.css' file.

    def Dark_Orange_Theme(self):
        # Set the dark orange theme for the UI
        style = open('themes/darkorange.css', 'r')
        style = style.read()
        self.setStyleSheet(style)

    # This function sets the dark orange theme for the UI by reading the CSS style from the 'qdark.css' file.

    def QDark_Theme(self):
        # Set the QDark theme for the UI
        style = open('themes/qdark.css', 'r')
        style = style.read()
        self.setStyleSheet(style)

    # This function sets the QDark theme for the UI by reading the CSS style from the 'qdark.css' file.

def main():
    app = QApplication(sys.argv)
    window = Login()
    window.show()
    app.exec_()

# The main function that creates an instance of the Login class, shows the window,
# and starts the application event loop.

if __name__ == '__main__':
    main()

# Entry point of the program, where the main function is called when the script is executed.
